package com.example.myrecipe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.VideoView;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        videoView = findViewById(R.id.splashVideoView);
        Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.intro_animation);
        videoView.setVideoURI(videoUri);

        videoView.setOnCompletionListener(mp -> {
            // Animation finished, now move to MainActivity
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        });

        videoView.setOnPreparedListener(MediaPlayer::start);
    }
}
