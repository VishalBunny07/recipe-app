package com.example.myrecipe;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder> {

    Context context;
    List<Recipe> recipeList;

    public RecipeAdapter(Context context, List<Recipe> recipeList) {
        this.context = context;
        this.recipeList = recipeList;
    }

    @NonNull
    @Override
    public RecipeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recipe_item, parent, false);
        return new RecipeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeViewHolder holder, int position) {
        Recipe recipe = recipeList.get(position);
        holder.recipeImage.setImageResource(recipe.getImageResId());
        holder.recipeTitle.setText(recipe.getTitle());
        holder.recipeType.setText(recipe.getType());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, RecipeDetailActivity.class);
            intent.putExtra("image", recipe.getImageResId());
            intent.putExtra("title", recipe.getTitle());
            intent.putExtra("type", recipe.getType());
            intent.putExtra("ingredients", recipe.getIngredients());
            intent.putExtra("instructions", recipe.getInstructions());

            // ✅ Add video URL for each recipe
            String videoUrl = getVideoUrlForRecipe(position);
            intent.putExtra("video_url", videoUrl);

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return recipeList.size();
    }

    public static class RecipeViewHolder extends RecyclerView.ViewHolder {
        ImageView recipeImage;
        TextView recipeTitle, recipeType;

        public RecipeViewHolder(@NonNull View itemView) {
            super(itemView);
            recipeImage = itemView.findViewById(R.id.recipeImage);
            recipeTitle = itemView.findViewById(R.id.recipeTitle);
            recipeType = itemView.findViewById(R.id.recipeType);
        }
    }

    // Method to get video URL based on position
    private String getVideoUrlForRecipe(int position) {
        switch (position) {
            case 0:
                return "https://www.youtube.com/watch?v=VIDEO_ID_1";
            case 1:
                return "https://www.youtube.com/watch?v=VIDEO_ID_2";
            case 2:
                return "https://www.youtube.com/watch?v=VIDEO_ID_3";
            case 3:
                return "https://www.youtube.com/watch?v=VIDEO_ID_4";
            // Add more cases as needed
            default:
                return "https://www.youtube.com";
        }
    }
}
