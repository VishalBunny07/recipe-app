package com.example.myrecipe;

public class Recipe {
    private String title;
    private int image;
    private String type;
    private String ingredients;
    private String instructions;
    private String videoUrl;

    public Recipe(String title, int image, String type, String ingredients, String instructions, String videoUrl) {
        this.title = title;
        this.image = image;
        this.type = type;
        this.ingredients = ingredients;
        this.instructions = instructions;
        this.videoUrl = videoUrl;
    }

    public String getTitle() { return title; }
    public int getImageResId() { return image; } // ✅ Renamed here
    public String getType() { return type; }
    public String getIngredients() { return ingredients; }
    public String getInstructions() { return instructions; }
    public String getVideoUrl() { return videoUrl; }
}
