package com.example.myrecipe;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Xml;
import android.view.Window;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RecipeAdapter adapter;
    List<Recipe> recipeList;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Dynamically change system navigation bar color based on theme
        setNavigationBarColor();

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recipeList = new ArrayList<>();

        loadRecipesFromXml(); // Load from res/raw/recipes.xml

        adapter = new RecipeAdapter(this, recipeList);
        recyclerView.setAdapter(adapter);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                Toast.makeText(MainActivity.this, "Home selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.nav_favorites) {
                Toast.makeText(MainActivity.this, "Favorites selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.nav_profile) {
                Toast.makeText(MainActivity.this, "Profile selected", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });
    }

    private void loadRecipesFromXml() {
        try {
            Resources res = getResources();
            InputStream inputStream = res.openRawResource(R.raw.recipes);
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(inputStream, null);

            int eventType = parser.getEventType();
            String title = null, type = null, ingredients = null, instructions = null, videoUrl = null;
            int imageResId = 0;

            while (eventType != XmlPullParser.END_DOCUMENT) {
                String tagName = parser.getName();

                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if ("recipe".equals(tagName)) {
                            title = type = ingredients = instructions = videoUrl = null;
                            imageResId = 0;
                        } else if ("title".equals(tagName)) {
                            title = parser.nextText();
                        } else if ("type".equals(tagName)) {
                            type = parser.nextText();
                        } else if ("image".equals(tagName)) {
                            String imageName = parser.nextText().trim();
                            imageResId = getResources().getIdentifier(imageName, "drawable", getPackageName());
                        } else if ("ingredients".equals(tagName)) {
                            ingredients = cleanTextBlock(parser.nextText(), true); // Add bullets
                        } else if ("instructions".equals(tagName)) {
                            instructions = cleanTextBlock(parser.nextText(), false); // Step-by-step plain
                        } else if ("videoUrl".equals(tagName)) {
                            videoUrl = parser.nextText().trim();
                        }
                        break;

                    case XmlPullParser.END_TAG:
                        if ("recipe".equals(tagName)) {
                            recipeList.add(new Recipe(title, imageResId, type, ingredients, instructions, videoUrl));
                        }
                        break;
                }
                eventType = parser.next();
            }

            inputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading recipes", Toast.LENGTH_SHORT).show();
        }
    }

    private String cleanTextBlock(String input, boolean addBullets) {
        String[] lines = input.split("\n");
        StringBuilder cleaned = new StringBuilder();
        for (String line : lines) {
            if (!line.trim().isEmpty()) {
                if (addBullets) {
                    cleaned.append("• ").append(line.trim()).append("\n");
                } else {
                    cleaned.append(line.trim()).append("\n");
                }
            }
        }
        return cleaned.toString().trim();
    }

    private void setNavigationBarColor() {
        int currentNightMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        Window window = getWindow();
        if (currentNightMode == Configuration.UI_MODE_NIGHT_YES) {
            window.setNavigationBarColor(getResources().getColor(android.R.color.background_dark, getTheme()));
        } else {
            window.setNavigationBarColor(getResources().getColor(android.R.color.background_light, getTheme()));
        }
    }
}
