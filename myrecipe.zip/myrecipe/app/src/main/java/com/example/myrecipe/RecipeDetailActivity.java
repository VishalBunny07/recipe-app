package com.example.myrecipe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RecipeDetailActivity extends AppCompatActivity {

    ImageView detailImage;
    TextView detailTitle, detailType, detailIngredients;
    LinearLayout cookingStepsContainer;
    Button btnWatchVideo;
    String videoUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recipe_detail);

        detailImage = findViewById(R.id.detail_image);
        detailTitle = findViewById(R.id.detail_title);
        detailType = findViewById(R.id.detail_type);
        detailIngredients = findViewById(R.id.detail_ingredients);
        cookingStepsContainer = findViewById(R.id.cooking_steps_container);
        btnWatchVideo = findViewById(R.id.btnWatchVideo);

        // Get data from Intent
        int image = getIntent().getIntExtra("image", R.drawable.recipe1);
        String title = getIntent().getStringExtra("title");
        String type = getIntent().getStringExtra("type");
        String ingredients = getIntent().getStringExtra("ingredients");
        String instructions = getIntent().getStringExtra("instructions");
        videoUrl = getIntent().getStringExtra("videoUrl");

        detailImage.setImageResource(image);
        detailTitle.setText(title);
        detailType.setText(type);
        detailIngredients.setText(ingredients);

        // Dynamically add CheckBoxes for each cooking step
        if (instructions != null && !instructions.isEmpty()) {
            String[] steps = instructions.split("\\n");

            for (String step : steps) {
                CheckBox checkBox = new CheckBox(this);
                checkBox.setText(step.trim());
                checkBox.setTextSize(16);
                checkBox.setTextColor(getResources().getColor(R.color.black)); // Use your desired color
                checkBox.setPadding(8, 8, 8, 8);
                cookingStepsContainer.addView(checkBox);
            }
        }

        // Open YouTube video in browser or app
        btnWatchVideo.setOnClickListener(v -> {
            if (videoUrl != null && !videoUrl.isEmpty()) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(this, "Unable to open video.", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(this, "Video URL not available.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
